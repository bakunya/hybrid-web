import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { uid } from 'uid';

@Component({
  selector: 'app-history',
  templateUrl: './history.page.html',
  styleUrls: ['./history.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class HistoryPage implements OnInit {
  public loading: boolean;
  public error: boolean;
  public data: any;
  public loadingHistory: boolean;
  public errorHistory: boolean;
  public dataHistory: any;
  public historyDate: any;
  public currentData: undefined | any = undefined;
  public isModalOpen: boolean = false;
  
  constructor() {
    this.loading = false
    this.error = false
    this.data = null
    this.loadingHistory = false
    this.errorHistory = false
    this.dataHistory = null
    this.historyDate = null
  }

  public modalToggle(v: any) {
    this.currentData = v
    this.isModalOpen = !this.isModalOpen
  }

  /**
   * 
   * @param i as WeatherObject
   */
  public handleSave(i: any) {
    const l = localStorage.getItem("WEATHER")
    if (!l) {
      localStorage.setItem("WEATHER", JSON.stringify([{
        ...i,
        id: uid()
      }]))
    } else {
      const p = JSON.parse(l) as any[]
      p.unshift({
        ...i,
        id: uid()
      })
      localStorage.setItem("WEATHER", JSON.stringify(p))
    }
    this.isModalOpen = false
  }

  ngOnInit() {
    this.setHistoryDate()
    this.getWeather()
    this.getHistory()
  }

  setHistoryDate() {
    const d = new Date()
    d.setDate(d.getDate() - 1)
    this.historyDate = d.toISOString().split('T')[0]
  }

  async getWeather() {
    this.loading = true
    this.error = false
    try {
      const raw = await fetch(`https://api.weatherapi.com/v1/current.json?key=2f13b7ad30cb46dfbc143038230306 &q=Yogyakarta&aqi=no`)
      this.data = await raw.json()
    } catch (err) {
      console.error(err)
      this.error = true
    } finally {
      this.loading = false
    }
  }

  async getHistory() {
    this.loadingHistory = true
    this.errorHistory = false
    try {
      const raw = await fetch(`http://api.weatherapi.com/v1/history.json?key=2f13b7ad30cb46dfbc143038230306&q=Yogyakarta&dt=${this.historyDate}`)
      this.dataHistory = await raw.json()
    } catch (err) {
      console.error(err)
      this.errorHistory = true
    } finally {
      this.loadingHistory = false
    }
  }
}
