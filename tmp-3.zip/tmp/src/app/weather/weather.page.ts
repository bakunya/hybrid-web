import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { uid } from 'uid';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.page.html',
  styleUrls: ['./weather.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class WeatherPage implements OnInit {
  public loading: boolean;
  public error: boolean;
  public data: any;
  public loadingHistory: boolean;
  public errorHistory: boolean;
  public dataHistory: any;
  public loadingForecast: boolean;
  public errorForecast: boolean;
  public dataForecast: any;
  public isModalOpen: boolean = false;
  public currentData: undefined | any;

  constructor() { 
    this.loading = false
    this.error = false
    this.data = null
    this.loadingHistory = false
    this.errorHistory = false
    this.dataHistory = null
    this.loadingForecast = false
    this.errorForecast = false
    this.dataForecast = null
    this.currentData = undefined
  }

  public modalToggle(v: any) {
    this.currentData = v
    this.isModalOpen = !this.isModalOpen
  }

  ngOnInit() {
    this.getWeather()
    this.getHistory()
    this.getForecast()
  }

  /**
   * 
   * @param i as WeatherObject
   */
  public handleSave(i: any) {
    const l = localStorage.getItem("WEATHER")
    if(!l) {
      localStorage.setItem("WEATHER", JSON.stringify([{
        ...i,
        id: uid()
      }]))
    } else {
      const p = JSON.parse(l) as any[]
      p.unshift({
        ...i,
        id: uid()
      })
      localStorage.setItem("WEATHER", JSON.stringify(p))
    }
    this.isModalOpen = false
  }

  async getWeather() {
    this.loading = true
    this.error = false
    try {
      const raw = await fetch(`https://api.weatherapi.com/v1/current.json?key=2f13b7ad30cb46dfbc143038230306 &q=Yogyakarta&aqi=no`)
      this.data = await raw.json()
    } catch (err) {
      console.error(err)
      this.error = true
    } finally {
      this.loading = false
    }
  }

  async getHistory() {
    this.loadingHistory = true
    this.errorHistory = false
    try {
      const raw = await fetch(`http://api.weatherapi.com/v1/history.json?key=2f13b7ad30cb46dfbc143038230306&q=Yogyakarta&dt=2023-06-03`)
      this.dataHistory = await raw.json()
    } catch (err) {
      console.error(err)
      this.errorHistory = true
    } finally {
      this.loadingHistory = false
    }
  }

  async getForecast() {
    this.loadingForecast = true
    this.errorForecast = false
    try {
      const raw = await fetch(`http://api.weatherapi.com/v1/forecast.json?key=2f13b7ad30cb46dfbc143038230306&q=Yogyakarta`)
      this.dataForecast = await raw.json()
    } catch (err) {
      console.error(err)
      this.errorForecast = true
    } finally {
      this.loadingForecast = false
    }
  }
}
