import { Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

export const routes: Routes = [
  {
    path: '',
    component: TabsPage,
    children: [
      {
        path: 'forecast',
        loadComponent: () =>
          import('../weather/weather.page').then((m) => m.WeatherPage),
      },
      {
        path: 'history',
        loadComponent: () =>
          import('../history/history.page').then((m) => m.HistoryPage),
      },
      {
        path: 'bookmarks',
        loadComponent: () =>
          import('../bookmarks/bookmarks.page').then((m) => m.BookmarksPage),
      },
      {
        path: '',
        redirectTo: '/forecast',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    loadComponent: () =>
      import('../weather/weather.page').then((m) => m.WeatherPage),
  },
];
