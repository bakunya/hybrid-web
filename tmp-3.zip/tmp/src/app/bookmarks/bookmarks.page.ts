import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-bookmarks',
  templateUrl: './bookmarks.page.html',
  styleUrls: ['./bookmarks.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})
export class BookmarksPage implements OnInit {
  public loading: boolean = false;
  public error: boolean = false;
  public data: any = false;
  public dataBookmarks: any[] = []
  public currentData: undefined | any = undefined
  public isModalOpen: boolean = false;

  constructor() {}

  ngOnInit() {
    this.getWeather().catch(console.error)
  }

  ngDoCheck() {
    const l = localStorage.getItem("WEATHER")
    if(!l) return
    this.dataBookmarks = JSON.parse(l)
    console.log(this.dataBookmarks)
  }

  async getWeather() {
    this.loading = true
    this.error = false
    try {
      const raw = await fetch(`https://api.weatherapi.com/v1/current.json?key=2f13b7ad30cb46dfbc143038230306 &q=Yogyakarta&aqi=no`)
      this.data = await raw.json()
    } catch (err) {
      console.error(err)
      this.error = true
    } finally {
      this.loading = false
    }
  }

  public modalToggle(v: any) {
    this.currentData = v
    this.isModalOpen = !this.isModalOpen
  }

  /**
   * 
   * @param i as WeatherObject
   */
   public handleDelete(i: any) {
    const l = localStorage.getItem("WEATHER")
    if (!l) return
    const p = JSON.parse(l) as any[]
    localStorage.setItem("WEATHER", JSON.stringify(p.filter(v => v.id !== i.id)))
    this.isModalOpen = false
  }
}
